package br.com.agr.talhagr2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TalhAgr2Application {

	public static void main(String[] args) {
		SpringApplication.run(TalhAgr2Application.class, args);
	}

}
