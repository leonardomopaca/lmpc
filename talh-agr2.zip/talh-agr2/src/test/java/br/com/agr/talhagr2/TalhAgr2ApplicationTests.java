package br.com.agr.talhagr2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TalhAgr2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
