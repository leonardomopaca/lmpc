package br.com.agr.talhagr3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TalhAgr3Application {

	public static void main(String[] args) {
		SpringApplication.run(TalhAgr3Application.class, args);
	}

}
