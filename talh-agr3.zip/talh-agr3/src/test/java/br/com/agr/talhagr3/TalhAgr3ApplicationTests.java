package br.com.agr.talhagr3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TalhAgr3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
