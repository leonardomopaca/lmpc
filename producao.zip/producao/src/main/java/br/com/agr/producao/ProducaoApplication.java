package br.com.agr.producao;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProducaoApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProducaoApplication.class, args);
	}

}
