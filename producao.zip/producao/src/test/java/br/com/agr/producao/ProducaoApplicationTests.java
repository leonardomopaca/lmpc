package br.com.agr.producao;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProducaoApplicationTests {

	@Test
	void contextLoads() {
	}

}
